GLP-1 이상사례 PBL 수업 결과
GLP1_Interactive_Dashboard.html — 압축을 모두 풀고 브라우저에서 열기. 필터 변경 및 집계 CSV 내보내기.
clean_data/ — 재구성한 신고표와 반응표(CSV.GZ). 두 표의 공통 키는 safetyreportid.
figures/ — 각 그림에 600 dpi PNG·PDF·SVG. B가 선형 모형이면 반응명 계수 그림도 출력.
tables/01* — 정제·품질 감사. 02* — EDA. 03* — 기간·어휘·구성. 04* — 검증과 보정. 05* — 시간 시험. 06* — 최종 모델 설명.
run_info.json — 입력 해시, 기간, 모델, 임계값, 패키지 버전.
회고적 신고 분류 실험. 각 성분·환자군의 투약 인원 분모는 제공되지 않음.
